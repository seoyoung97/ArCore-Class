package com.example.ex02_arcore_camera;

import android.content.Context;
import android.graphics.Color;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;

import com.google.ar.core.Session;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainRenderer implements GLSurfaceView.Renderer {

    CameraPreview mCamera;
    PointCloudRenderer mPointCloud;
    boolean mViewportChanged;
    int mViewportWidth, mViewportHeight;
    RenderCallBack mRenderCallBack;
    PlaneRenderer mPlane;
    Cube mCube;
    ObjRenderer mObj;

    MainRenderer(Context context, RenderCallBack callBack) {
        mRenderCallBack = callBack;
        mCamera = new CameraPreview();
        mPointCloud = new PointCloudRenderer();
        mPlane = new PlaneRenderer(Color.BLUE, 0.7f);

        // Cube 생성
        mCube = new Cube(0.3f, Color.YELLOW, 0.8f);
        mObj = new ObjRenderer(context, "andy.obj", "andy.png");
       // mObj = new ObjRenderer(context, "oculos.obj", "b.png");

    }

    interface RenderCallBack {
        void preRender();
    }

    // Surface가 생성될 때 호출
    @Override
    public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {
        // 3차원 좌표
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glEnable(GLES30.GL_BLEND);
        // 색상
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA);
        GLES30.glClearColor(0.2f, 0.3f, 0.4f, 1.0f);

        mCamera.init();
        mPointCloud.init();
        mPlane.init();
        mCube.init();
        mObj.init();
    }

    // Surface Size가 변경될 때 호출, onSurfaceCreated()가 호출될 때마다 호출
    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES30.glViewport(0, 0, width, height);
        mViewportChanged = true;
        mViewportWidth = width;
        mViewportHeight = height;
    }

    // Rendering 수행
    @Override
    public void onDrawFrame(GL10 gl10) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

        mRenderCallBack.preRender();
        GLES30.glDepthMask(false);
        mCamera.draw();
        GLES30.glDepthMask(true);
        mPointCloud.draw();

        mPlane.draw();
        mCube.draw();
        mObj.draw();
    }

    void updateSession(Session session, int displayRotation) {
        if (mViewportChanged) {
            session.setDisplayGeometry(displayRotation, mViewportWidth, mViewportHeight);
            mViewportChanged = false;
        }
    }

    void setProjectionMatrix(float[] matrix) {
        mPointCloud.updateProjMatrix(matrix);
        mPlane.setProjectionMatrix(matrix);
        mCube.setProjectionMatrix(matrix);
        mObj.setProjectionMatrix(matrix);
    }

    void updateViewMatrix(float[] matrix) {
        mPointCloud.updateViewMatrix(matrix);
        mPlane.setViewMatrix(matrix);
        mCube.setViewMatrix(matrix);
        mObj.setViewMatrix(matrix);
    }

    int getTextureID() {
        return mCamera == null ? -1 : mCamera.mTextures[0];
    }

}